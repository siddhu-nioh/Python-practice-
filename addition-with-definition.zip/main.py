def add(a,b):
    c=a+b
    print(c)

a=input('name1')
b=input("name3")
add(a,b)
a=int(input("enter num1--->"))
b=int(input("enter num2-->"))
add(a,b)