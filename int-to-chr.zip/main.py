n=int(input())
a=65
for i in range(n):
    i=a
    print(chr(i))
    a=a+1